sap.ui.define([
    "./BaseController"
], function (BaseController) {
    "use strict";

    return BaseController.extend("wbui5.controller.DetailObjectNotFound", {});
});